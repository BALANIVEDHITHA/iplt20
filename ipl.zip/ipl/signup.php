<?php
if(isset($_POST['signup']))
{
	
$username= $_POST['username'];
//echo $username;
echo"<br>";
$password= $_POST['password'];
//echo $password;
echo "<br>";

//connection to database
//mysqli_connect(host,username,password,databasename);
$con=mysqli_connect("localhost","u121762129_bala","sastra123","u121762129_ipl");
//inser to the database
mysqli_query($con,"Insert into users(username,password) Values('$username','$password')");

echo registeredsuccessfully;



}
else
{
	header("Location:index.html");
	exit(0);
}







?>